package com.example.hellofx;

public enum Gender {
    MALE,
    FEMALE;
}
