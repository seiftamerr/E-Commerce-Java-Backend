package com.example.hellofx;

public enum PaymentMethod {
    CreditCard,
    DebitCard,
    Cash;
}

